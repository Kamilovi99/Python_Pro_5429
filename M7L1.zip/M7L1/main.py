import discord, os
from discord.ext import commands
from dotenv import load_dotenv
import clases

load_dotenv
token = os.getenv("dt")

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="$",intents=intents)

@bot.event
async def on_ready():
    print(f"Iniciado en: {bot.user.name}")

@bot.command(name="file")
async def check(ctx):
    archivos = ctx.message.attachments
    if archivos:
        for archivo in archivos:
            file_name = archivo.filename
            file_url = archivo.url
            await archivo.save(f"./{file_name}")
            await ctx.send(f"Guardado en ./{file_name}")
    else:
        await ctx.send("**No se encontraron archivos**")

@bot.command(name="predict")
async def clasify(ctx):
    archivos = ctx.message.attachments
    if archivos:
        for archivo in archivos:
            file_name = archivo.filename
            file_url = archivo.url
            await archivo.save(f"./{file_name}")
            class_name, confidence = clases.predict_image(f"./{file_name}")
            percentage = confidence * 100

            embed = discord.Embed(
                title="**RESULTADOS DE CLASIFICACIÓN**",
                description=f"**Clase:** {class_name}\n**Confianza:** {percentage:.2f}",
                color=0x088c8c
            )

            embed.add_field(
                name="**Información adicional**",
                value="bot en desarrollo, no usar en nada serio"   
            )

            embed.set_thumbnail(
                url= file_url
            )

            embed.set_author(
                name="Henry Ruiz"
            )

            embed.set_footer(
                text="Creado con Keras y TensorFlow",
                icon_url="https://raw.githubusercontent.com/tensorflow/tensorflow/master/tensorflow/lite/g3doc/images/tf_logo.png"
            )

            await ctx.send(embed=embed)
            os.remove(f"./{file_name}")

    else:
        await ctx.send("**No se encontraron archivos**")



bot.run(token)